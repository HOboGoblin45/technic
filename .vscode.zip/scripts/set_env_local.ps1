# Example environment setup for Technic (PowerShell).
# Copy this file to set_env_local.ps1, replace placeholder values, then source it:
#   . .\scripts\set_env_local.ps1

$env:POLYGON_API_KEY = "55pXiNYqZxIeAo2aSSpi5BHha8yGHbZT"
$env:FMP_API_KEY = "sNxuAEXhLhUNCfczvakuzuRduiIjOnnT"               # optional fundamentals source
$env:TECHNIC_API_KEY = "ba4c5f8a6f3d4931b7a2c0e5d9f14c76"    # optional API auth
$env:OPENAI_API_KEY = "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"

# Optional scoreboard sync (set both if you use a remote sync target)
$env:SCOREBOARD_SYNC_URL = "http://127.0.0.1:8000/scoreboard"
$env:SCOREBOARD_SYNC_TOKEN = "ba4c5f8a6f3d4931b7a2c0e5d9f14c76"
# If you want the scoreboard service to enforce auth, set its API token to match
$env:SCOREBOARD_API_TOKEN = "ba4c5f8a6f3d4931b7a2c0e5d9f14c76"

# Supabase (optional if you sync scoreboard there)
$env:SUPABASE_URL="https://rqpivhyrpxflnblmqspp.supabase.co"
$env:SUPABASE_ANON_KEY="sb_publishable_l-A3SkS9p_2ZrHVrXstOFw_POVSQnJm"
$env:SUPABASE_USER_ID="8de4aa71-bc66-4849-8d12-0edf3b181593"

Write-Host "Environment variables set for this PowerShell session."
